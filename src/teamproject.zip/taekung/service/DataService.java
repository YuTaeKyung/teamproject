package teamproject.taekung.service;

/**
 * Created by taeku on 2016-09-14.
 */
public interface DataService {
}
