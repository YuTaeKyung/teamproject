package teamproject.taekung.VO;

/**
 * Created by taeku on 2016-09-14.
 */
public class RentVO {
}
